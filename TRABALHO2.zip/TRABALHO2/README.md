# HealthSys - Sistema de Gerenciamento de Dados de Pacientes (Parte I)

## 1. Descrição Geral do Projeto

Este projeto consiste na implementação da Parte I de um sistema simplificado para gerenciamento de dados de pacientes de uma clínica, desenvolvido em linguagem C. Para esta entrega, o foco está nas funcionalidades de consulta e listagem de registros de pacientes[cite: 3]. Os dados dos pacientes são persistidos em um arquivo CSV (`bd_paciente.csv`) e carregados em memória (um vetor estático) para manipulação pelo sistema[cite: 1, 4].

## 2. Funcionalidades Implementadas (Parte I)

O sistema atualmente oferece as seguintes funcionalidades principais:

* **Consultar Paciente:** Permite buscar pacientes por Nome ou CPF[cite: 28]. A busca é realizada com base em prefixos [cite: 30] (não diferencia maiúsculas de minúsculas) e exibe os registros completos dos pacientes encontrados.
* **Imprimir Lista de Pacientes:** Exibe todos os registros de pacientes armazenados no sistema de forma organizada e paginada (10 pacientes por página)[cite: 33].
* **Sair do Sistema:** Encerra a execução do programa[cite: 11].

## 3. Estrutura do Repositório e Arquivos

O projeto está organizado nos seguintes arquivos e diretórios:

* `Makefile`: Arquivo de compilação para construir o projeto.
* `programa` (ou o nome do seu executável final): O programa executável gerado após a compilação.
* `main.c`: Contém a função principal (`main`) que inicializa o sistema, carrega os dados e gerencia o menu principal e o fluxo do programa[cite: 38].
* `paciente.h`: Define a estrutura de dados (`struct Paciente`) para um paciente e constantes relacionadas (como `MAX_NOME`, `MAX_CPF`).
* `paciente.c`: Contém funções auxiliares relacionadas a um único paciente (ex: `imprimir_paciente`).
* `bd_paciente.h`: Define o Tipo Abstrato de Dados (TAD) `BDPaciente`, incluindo a estrutura do banco de dados em memória (vetor estático de pacientes [cite: 4]) e os protótipos das funções para manipular esses dados (carregar, consultar, listar).
* `bd_paciente.c`: Implementa as funções do TAD `BDPaciente` (lógica de carregamento do CSV, buscas por prefixo, listagem paginada).
* `interface.h`: Declara as funções responsáveis pela interação com o usuário (exibição de menus, coleta de entradas, formatação de saídas).
* `interface.c`: Implementa as funções de interface com o usuário.
* `bd_paciente.csv`: Arquivo texto CSV que armazena os dados dos pacientes[cite: 1]. Deve estar presente no mesmo diretório do executável para o carregamento correto dos dados.
    * **Formato:** `ID,CPF,Nome,Idade,Data_Cadastro` (Ex: `1,123.456.789-09,Joao Silva,45,2024-12-01`)
* `README.md`: Este arquivo de documentação.

## 4. Principais TADs Utilizados

### 4.1. TAD `Paciente` (`paciente.h`)

* **Definição:** `struct Paciente`
* **Campos:**
    * `int id`: Identificador único do paciente.
    * `char cpf[MAX_CPF]`: CPF do paciente (formato `XXX.XXX.XXX-XX`).
    * `char nome[MAX_NOME]`: Nome completo do paciente.
    * `int idade`: Idade do paciente em anos.
    * `char data_cadastro[MAX_DATA_CADASTRO]`: Data de cadastro no formato `AAAA-MM-DD`.
* **Responsabilidade:** Representar os dados de um único paciente.

### 4.2. TAD `BDPaciente` (`bd_paciente.h`)

* **Definição:** `struct BDPaciente`
* **Estrutura Interna:** Contém um vetor estático de `Paciente` com capacidade para `MAX_PACIENTES` (definido como 500) e um contador para a quantidade atual de pacientes[cite: 4].
* **Principais Funções:**
    * `inicializar_bd()`: Prepara o banco de dados em memória.
    * `carregar_dados_csv()`: Lê os dados do `bd_paciente.csv` para o vetor em memória[cite: 13].
    * `consultar_pacientes_por_nome()`: Busca pacientes por prefixo do nome.
    * `consultar_pacientes_por_cpf()`: Busca pacientes por prefixo do CPF.
    * `imprimir_lista_pacientes_paginada()`: Lista todos os pacientes com paginação.
* **Responsabilidade:** Abstrair o armazenamento e a manipulação da coleção de dados dos pacientes[cite: 21].

## 5. Instruções de Compilação e Execução

### 5.1. Pré-requisitos

* Compilador GCC (o projeto foi desenvolvido pensando no GCC 11 em um ambiente Linux Ubuntu 22.04, conforme especificado [cite: 56]).
* Utilitário `make`.

### 5.2. Compilação

Para compilar o projeto, navegue até o diretório raiz do projeto no terminal e execute o comando:

```bash
make